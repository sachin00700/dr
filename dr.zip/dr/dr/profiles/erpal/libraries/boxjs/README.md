BoxJS
============
![BoxJS Logo](http://www.morpol.de/sites/default/files/styles/thumbnail/public/projects/boxjs-2.png)
BoxJS is a simple JavaScript web framework allowing you to easily manage and display small content boxes shown above your actual webpage, e.g. background file upload handlers, progress boxes or small forms. 
Requires createClass as well as jQuery. Will use Inter Tab JS to sync boxes between tabs/windows if available and configured.