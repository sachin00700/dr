createClass
============
![createClass Logo](http://www.morpol.de/sites/default/files/styles/thumbnail/public/projects/createclass-2.png)
A fully functional OOP framework that's still based on JavaScript's own OOP understanding, tools and syntax (i.e. Prototyping).


Examples
------------
[Example 1](example01.html)  
[Example 2](example02.html)  
[Example 3](example03.html)  